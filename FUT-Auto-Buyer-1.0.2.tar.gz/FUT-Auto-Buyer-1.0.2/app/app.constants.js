export const MAX_CLUB_SEARCH = 90;
export const MAX_MARKET_SEARCH = 20;
