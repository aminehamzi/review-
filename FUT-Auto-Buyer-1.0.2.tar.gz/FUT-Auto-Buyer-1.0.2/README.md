# Fifa21-AutoBuyer

[![Contributors][contributors-shield]][contributors-url]
[![Forks][forks-shield]][forks-url]
[![Stargazers][stars-shield]][stars-url]
[![Issues][issues-shield]][issues-url]
[![Total Downloads](https://img.shields.io/github/downloads/chithakumar13/Fifa21-AutoBuyer/total.svg)]()

<p align="center"> 
  <h3 align="center">Fifa21 AutoBuyer</h3>

  <p align="center">
    FIFA 21 Auto Buyer For Web App!
    <br />  
    <br /> 
    <a href="https://github.com/chithakumar13/Fifa21-AutoBuyer/issues">Report Bug</a>
    ·
    <a href="https://github.com/chithakumar13/Fifa21-AutoBuyer/issues">Request Feature</a>
  .
  <a href="https://www.youtube.com/channel/UC5eLkjmLU2TcE4oiJM9PsyA?sub_confirmation=1">Subscribe</a>
  
  # Must Read :no_entry_sign:
  
  These tool is developed to demonstrate how someone can develop script to break our web application by automating stuffs and only for learning purpose.
  
   EA might (soft) ban from using transfer market in web app for using this tool. Continuously soft ban might lead to permanent ban as well. Also use of tools like this to gain advantage over other players is not ethically right.  
   
   Use this tool at your own risk, any developers contributing to this repo won’t held responsibility if your account gets banned.
  </p>
</p>

<!-- TABLE OF CONTENTS -->

## Table of Contents

- [Installation](#installation)
- [AutoSolve Captcha SetUp](#Captcha)
- [Usage](#Usage)
- [Prerequisites](#prerequisites)
- [Telegram Installation Guide](#Telegram-Installation-Guide)
- [Roadmap](#Roadmap)
- [Developer Guide](#Developer-Guide)
- [Contributing](#contributing)
- [Contact](#contact)

<!-- installation -->

## Installation

- Download the latest release from - [Latest Release](https://github.com/chithakumar13/Fifa21-AutoBuyer/releases/).
- Add Tamper Monkey Extenstion to your Browser.
- Navigate to Create Script -> Then to Utilities.
- Under Utilities -> File (Import the two Scripts and Install it).
- Installation And Demo - [Video Guide](https://www.youtube.com/watch?v=M3Jn4FI1nUw).

Now in Ultimate Team Web App, new menu will be added as AutoBuyer.

## Captcha

### AutoSolve Captcha Setup

- Follow this [video](https://www.youtube.com/watch?v=9p_IMe52LBo) if you are not sure how to set it up.

<!-- Usage -->

## Usage

### AutoBuyer Settings

### Sell Price

- If specified the autobuyer will list the bought item for the specified price.
- The tool will list all the cards in transfer target, make sure to move your cards to the club before running the tool to avoid losing the card.
- Give Sell Price as -1 to move to transfer list without selling.

### Buy Price

- If specified the autobuyer will buy the card matching the search critieria for the price less than or equal to specified price.

### Bid Price

- If specified the autobuyer will bid on the card matching the search critieria for the price less than or equal to specified price.

### Bid Exact

- By default tool will bid for the lowest possible price and gradually increase the bid , if this flag is enabled bot will directly bid for the specified bid price.

### Bid items expiring in:

- If specified tool will only bid on items expiring in the given time range.
- Default Value (`1H`) (S for seconds, M for Minutes, H for hours).

### Relist Unsold Items:

- If enabled bot will periodically check and relist expired item for the previous specified price

### \* Note : This will relist all expired items , not only the item which bot list. So check the Transfer List before enabling this to avoid losing cards

### Wait Time

- The autobuyer will wait for the specified time before making the next search request.
- Default Value (`7 - 15`).

### Min clear count

- The autobuyer will clear all the sold items from transfer list when the count exceeds the specified value.
- Default Value (`10`).

### Max purchases per search request

- Indicates the count of cards the tool should buy or bid from the results of each request.
- Default Value (`3`).

### Stop After

- If specified the tool will automatically stop after running the tool foe the specified interval.
- Default Value (`1H`) (S for seconds, M for Minutes, H for hours).

### Pause For

- The parameter has a dependency on Cycle Amount
- The tool will pause for the specified interval, if the the number of search request in the given cycle matches the specified cycle amount.
- Default Value (`0-0S`) (S for seconds, M for Minutes, H for hours).

### Pause Cycle

- Indicates the amount of search request to be made before pausing the tool.
- Default Value (`10`).

### Rating Filtering

- If specified tool will bid only on items which has rating with in the specified range.
- Default Value (`10` - `100`).

### Random Min Bid

- If enabled tool will randomize min bid for each search to avoid cached result.

### Random Min Buy

- If enabled tool will randomize min buy for each search to avoid cached result.

### Close On Captcha Trigger

- If enabled tool will close the web app when Captcha gets triggered.

### Delay After Buy

- If enabled tool will add 1 second delay after each buy request.

### Error Codes to stop bot

- List of error code on which bot should stop, value should be in csv format.
- Ex - 421,461,512

### Sound Notification

- If enabled tool will gives sound notification for actions like buy card / captcha trigger etc...

## Prerequisites

- To use this tool, the user should have access to the transfer market.
- Hence play the required number of games to get access to the transfer market before trying this tool.

<!-- Telegram -->

## Telegram-Installation-Guide

- Install Telegram
- Add @BotFather as a contact in telegram
- Send BotFather /newbot
- Type in your individual details like name etc.
- Follow the prompts, and finally copy it’s HTTP API Token
- Add your bot as a contact
- Send /start to your bot
- Visit this URL. https://api.telegram.org/botXXX:YYYYY/getUpdates (replace the XXX: YYYYY with your BOT HTTP API Token you just got from the Telegram B otFather)
- Here you can find your chat id (this process can take some minutes) --> e.g. "chat":{"id":133333338,"first_name":"John","last_name":"Player"
- Now you can add your bot token and chat id at the notification settings inside the bot GUI (near the Bottom)

<!-- ROADMAP -->

## Roadmap

See the [open issues](https://github.com/chithakumar13/Fifa21-AutoBuyer/issues) for a list of proposed features (and known issues).

## 💬 Community

If you are looking for help or any new feature request, join our discord group

<img src="https://img.shields.io/discord/768336764447621122?color=green&label=Discord&logo=discord&logoColor=white">

<a href="https://discord.gg/cktHYmp">Join</a>

<!-- DevGuide -->

## Developer-Guide

<a href="https://discord.gg/AHqdCWRw69">Join this discord channel</a>

<!-- CONTRIBUTING -->

## Contributing

Any contributions you make are **greatly appreciated**.

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/FeatureBranch`)
3. Commit your Changes (`git commit -m 'Add some FeatureBranch'`)
4. Push to the Branch (`git push origin feature/FeatureBranch`)
5. Open a Pull Request

<!-- CONTACT -->

## Contact

Instagram - [@Instagram](https://www.instagram.com/i_m_ck13/) - chithakumar13@gmail.com

Project Link: [https://github.com/chithakumar13/Fifa21-AutoBuyer](https://github.com/chithakumar13/Fifa21-AutoBuyer)

<!-- MARKDOWN LINKS & IMAGES -->

[contributors-shield]: https://img.shields.io/github/contributors/chithakumar13/Fifa21-AutoBuyer.svg?style=flat-square
[contributors-url]: https://github.com/chithakumar13/Fifa21-AutoBuyer/graphs/contributors
[forks-shield]: https://img.shields.io/github/forks/chithakumar13/Fifa21-AutoBuyer.svg?style=flat-square
[forks-url]: https://github.com/chithakumar13/Fifa21-AutoBuyer/network/members
[stars-shield]: https://img.shields.io/github/stars/chithakumar13/Fifa21-AutoBuyer.svg?style=flat-square
[stars-url]: https://github.com/chithakumar13/Fifa21-AutoBuyer/stargazers
[issues-shield]: https://img.shields.io/github/issues/chithakumar13/Fifa21-AutoBuyer.svg?style=flat-square
[issues-url]: https://github.com/chithakumar13/Fifa21-AutoBuyer/issues
