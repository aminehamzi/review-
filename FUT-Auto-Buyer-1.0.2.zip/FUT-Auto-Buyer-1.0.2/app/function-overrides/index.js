import { sideBarNavOverride } from "./sidebarnav-override";

export const initOverrides = () => {
  sideBarNavOverride();
};
