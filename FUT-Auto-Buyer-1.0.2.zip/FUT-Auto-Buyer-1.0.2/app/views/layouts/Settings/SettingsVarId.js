export const totalCardsToBuy = "totalCardsToBuy";
export const bidPrice = "bidPrice";
export const bidExpiringIn = "bidExpiringIn";
export const isBidExact = "isBidExact";
export const buyPrice = "buyPrice";

export const isCloseOnCaptchaTrigger = "isCloseOnCaptchaTrigger";
export const isAutoSolveCaptcha = "isAutoSolveCaptcha";
export const captchaKey = "captchaKey";
export const captchaProxy = "captchaProxy";
export const captchaProxyPort = "captchaProxyPort";
export const captchaProxyUserName = "captchaProxyUserName";
export const captchaProxyPassword = "captchaProxyPassword";

export const isAutoClearLog = "isAutoClearLog";
export const errorCodesToStop = "errorCodesToStop";

export const telegramBotToken = "telegramBotToken";
export const telegramChatId = "telegramChatId";
export const discordBotToken = "discordBotToken";
export const discordChannelId = "discordChannelId";
export const notificationType = "notificationType";
export const isSendNotification = "isSendNotification";
export const isToggleNotification = "isToggleNotification";

export const waittime = "waittime";
export const maxPurchasePerSearch = "maxPurchasePerSearch";
export const pauseCycle = "pauseCycle";
export const pauseFor = "pauseFor";
export const stopAfter = "stopAfter";
export const isAddDelay = "isAddDelay";

export const sellPrice = "sellPrice";
export const clearSoldCount = "clearSoldCount";
export const isRelistUnsold = "isRelistUnsold";
